<?php 
// CONNEXION A LA BDD
$pdoBlog = new PDO(
    'mysql:host=localhost;
    dbname=test',
    'root', /* NOM D'UTILISATEUR */
    '', /* POUR LES MOTS DE PASSE // vide sur PC */
    array(
        PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING,
        PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8', 
    )
);
?>