<?php
// 1- Je require ma connexion à la base de données
require('inc/bdd.inc.php');

// 2- Réception des infos de l'article sélectionné grâce aux infos récupérées dans l'URL avec $_GET
if(isset($_GET['id'])){
    $article = $pdoBlog->prepare(" SELECT * FROM articles WHERE id = :id ");
    $article->execute(array(
        ':id' => $_GET['id'],/* J'associe le marqueur vide à l'id de l'article */
    ));

    if($article->rowCount() == 0){/* si le code renvoie un id inconnu */
        header('location:articles.php');
        exit();
    }
    $resultat = $article->fetch(PDO::FETCH_ASSOC);
}else {
    header('location:articles.php');
    exit();
}

?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog - Page des articles</title>
    <!-- BOOTSWATCH CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootswatch/5.1.3/lux/bootstrap.min.css" integrity="sha512-B5sIrmt97CGoPUHgazLWO0fKVVbtXgGIOayWsbp9Z5aq4DJVATpOftE/sTTL27cu+QOqpI/jpt6tldZ4SwFDZw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>

    <div class="p-5 bg-primary">
        <div class="container">
            <h1 class="display-3 text-white"><?php echo $resultat['titre']; ?></h1>
            <p class="lead text-white"><?php echo $resultat['auteur']; ?></p>
            <p><small class="text-white"><?php echo $resultat['date_parution']; ?></small></p>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-8 mx-auto">
                <img src="<?php echo $resultat['image'] ?>" alt="Illustration article" class="img-fluid">
                <?php echo $resultat['contenu'] ?>
            </div>
        </div>
    </div>


    <!-- BOOTSWATCH JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>

</html>